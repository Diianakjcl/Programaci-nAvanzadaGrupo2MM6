/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comserial;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.TooManyListenersException;
import javax.comm.CommPort;
import javax.comm.CommPortIdentifier;
import javax.comm.PortInUseException;
import javax.comm.SerialPort;
import javax.comm.SerialPortEvent;
import javax.comm.SerialPortEventListener;
import javax.comm.UnsupportedCommOperationException;

public class puertoCom implements SerialPortEventListener {
Enumeration ports;
HashMap portMap = new HashMap();
//esta clase busca los puertos disponibles en la computadora--------------------
public void searchForPorts() {
System.out.println("Puertos Disponibles:");
ports = CommPortIdentifier.getPortIdentifiers();
while (ports.hasMoreElements()) {
CommPortIdentifier curPort = (CommPortIdentifier) ports.nextElement();
if (curPort.getPortType() == CommPortIdentifier.PORT_SERIAL) {
System.out.println(curPort.getName());
portMap.put(curPort.getName(), curPort);
}
}
System.out.println("-----------------");
}
CommPortIdentifier selectedPortIdentifier;
SerialPort serialPort;
boolean connected;
//Se conecta a un puerto COM
public void connect() {
String puerto = "COM2";//seleccionamos el puerto
selectedPortIdentifier = (CommPortIdentifier) portMap.get(puerto);
@SuppressWarnings("UnusedAssignment")
CommPort commPort = null;
try {
commPort = selectedPortIdentifier.open("Send Sms Java", 100);
serialPort = (SerialPort) commPort;
setSerialPortParameters();
connected = true;
System.out.println("conectado exitosamente a puerto " + puerto);
} catch (PortInUseException e) {
System.out.println("Puerto en uso");
} catch (Exception e) {
System.out.println("Error al abrir puerto.");
}
}

//Configuramos el puerto que vamos a utilizar
private void setSerialPortParameters() throws IOException {
int baudRate = 115200;
try {
serialPort.setSerialPortParams(baudRate,
SerialPort.DATABITS_8,
SerialPort.STOPBITS_1,
SerialPort.PARITY_NONE);
serialPort.setFlowControlMode(
SerialPort.FLOWCONTROL_NONE);
} catch (UnsupportedCommOperationException ex) {
throw new IOException("Unsupported serial port parameter");
}
}
InputStream input;
OutputStream output;

//preparamos el puerto para escribir y leer
public boolean initIOStream() {
boolean successful = false;
try {
//
input = serialPort.getInputStream();
output = serialPort.getOutputStream();
writeData("\nCanal de comunicación abierto");
successful = true;
return successful;
} catch (IOException e) {
System.out.println("Error al abrir Stream");
return successful;
}
}

//agregamos el listener
public void initListener() {
try {
serialPort.addEventListener(this);
serialPort.notifyOnDataAvailable(true);
System.out.println("Listo para enviar datos");
} catch (TooManyListenersException e) {
System.out.println("Demasiados escuchas");
}
}
//mandamos información mediante writedata
public void writeData(String aenviar) {
try {
output.write(aenviar.getBytes());
} catch (IOException ex) {
System.out.println("Error al enviar informacion");
}
}

//leemos la informacion
@Override
public void serialEvent(SerialPortEvent spe) {
if (spe.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
byte[] readBuffer = new byte[20];
try {
while (input.available() > 0) {
int numBytes = input.read(readBuffer);
}
System.out.print(new String(readBuffer));
} catch (IOException e) {
System.out.println(e);
}
}
}
public void disconnect() {
try {
writeData("\nCanal de comunicación cerrado");
serialPort.removeEventListener();
serialPort.close();
input.close();
output.close();
connected = false;
System.out.println("Desconexión exitosa");
} catch (Exception e) {
System.out.println("Error al desconectar");
}
}

}


