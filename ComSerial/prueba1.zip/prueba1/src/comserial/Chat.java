package comserial;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Chat extends JFrame implements ActionListener {
    
    JTextArea jta;
    JScrollPane jsp;
    JButton jbtn;
    JButton sal;
    String str;
    int flag;
    puertoCom obj = new puertoCom();
        
    public Chat(){
        jta=new JTextArea(10,20);
        jbtn=new JButton("Enviar");
        sal=new JButton("Salir");
        
        jsp=new JScrollPane(jta,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jbtn.addActionListener(this);
        
        sal.addActionListener(this);
        
        add(jsp);
        add(jbtn);
        add(sal);
        
        setSize(400,400);
        setLocationRelativeTo(null);
        setVisible(true);
        
        //inicia comunicación serial
        
        obj.searchForPorts();
        obj.connect();
        if (obj.connected == true) {
            if (obj.initIOStream() == true) {
                obj.initListener();
                      
        
        
}
        }
    }
    


    
 
    
public static void main(String[] args) throws Exception{
     
        new Chat();
        

}

@Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==jbtn){
        str=jta.getText();
        jta.setText(" ");
        obj.writeData("\n"+str);
        }
        if(ae.getSource()==sal){
            flag=1;
            obj.disconnect();
            System.exit(0);
        }
        
    }
}